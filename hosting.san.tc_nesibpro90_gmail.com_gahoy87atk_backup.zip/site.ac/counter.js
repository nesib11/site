
        "use strict";
        if (document.referrer) {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) { console.log(this.responseText); }
            };
            xhttp.open("POST", "/site.ac/counter-set.js", true);
            xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhttp.send("t=2021.11.06 19:48:26&h=hosting.san.tc&i=104.227.66.152&r="+document.referrer);
        }
    